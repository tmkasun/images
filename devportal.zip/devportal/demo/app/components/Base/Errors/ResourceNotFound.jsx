/*
 * Copyright (c) 2019, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import React from 'react';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';

const ResourceNotFound = () => {
    return (
        <Container maxWidth='md'>
            <Box padding={4}>
                <Paper elevation={0}>
                    <Box padding={4}>
                        <div className='w3-container w3-green'>
                            <h1>Sorry</h1>
                            <h1>40fwefewfew4 - The padsfgsdfsdfsdfge cannot be found</h1>
                        </div>
                        <div className='w3-container w3-light-grey'>
                            <p>We cannot find the page you are looking for.</p>
                            <p>It might have been removed, had its name changed, or is temporarily unavailable. </p>
                            <p>Please check that the Web site address is spelled correctly.</p>
                            <p>
                                Or go to our {' '}
                                <a href='/devportal'>home page</a>, and use the menus to navigate to a specific
                                section.
                            </p>
                        </div>
                    </Box>
                </Paper>
            </Box>
        </Container>
    );
};

export default ResourceNotFound;

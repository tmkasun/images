/* eslint-disable */
/*
 * Copyright (c) 2019, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 Inc. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import { FormattedMessage, injectIntl } from 'react-intl';
import { Link } from 'react-router-dom';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';

import { ScopeValidation, resourceMethods, resourcePaths } from 'AppComponents/Shared/ScopeValidation';
import CustomIcon from 'AppComponents/Shared/CustomIcon';
import Loading from 'AppComponents/Base/Loading/Loading';
import Application from 'AppData/Application';
import Settings from 'AppComponents/Shared/SettingsContext';
import { appSettings } from 'Settings';

/**
 *
 * @inheritdoc
 * @param {*} theme theme object
 */
const styles = (theme) => ({
    card: {
        '& a': {
            color: 'inherit',
        },
        maxWidth: 270,
        minHeight: 250,
        paddingBottom: 20,
    },
    media: {
        height: 220,
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    pos: {
        marginBottom: 12,
        color: theme.palette.text.secondary,
    },
    createAppWrapper: {
        textDecoration: 'none',
    },
    divider: {
        marginBottom: 20,
    },
    createButton: {
        textDecoration: 'none',
        display: 'inline-block',
        marginLeft: 20,
        alignSelf: 'flex-start',
    },
    titleWrapper: {
        display: 'flex',
    },
    // New styles
    // //////////////////////
    content: {
        flexGrow: 1,
    },
    root: {
        height: 80,
        background: theme.custom.infoBar.background,
        color: theme.palette.getContrastText(theme.custom.infoBar.background),
        borderBottom: `solid 1px ${theme.palette.grey.A200}`,
        display: 'block',
    },
    mainIconWrapper: {
        paddingTop: theme.spacing(1.5),
        paddingLeft: theme.spacing(3),
        paddingRight: theme.spacing(2.5),
    },
    mainTitleWrapper: {
        display: 'flex',
    },
    createLinkWrapper: {
        paddingLeft: theme.spacing(2),
    },
    appContent: {
        marginTop: theme.spacing(2),
        maxWidth: '95%',
        margin: 'auto',
        maxHeight: theme.spacing(90),
        height: theme.spacing(90),
        overflow: 'scroll',
    },
    dialogContainer: {
        width: 1000,
        padding: theme.spacing(2),
    },
    fullHeight: {
        height: '100%',
    },
    container: {
        height: '100%',
    },
});

/**
 * @inheritdoc
 * @class Listing
 * @extends {Component}
 */
class Listing extends Component {
    static contextType = Settings;

    /**
     *
     * @param {any} props properties
     */
    constructor(props) {
        super(props);
        this.state = {
            order: 'asc',
            orderBy: 'name',
            data: null,
            page: 0,
            rowsPerPage: 10,
            open: false,
            isApplicationSharingEnabled: true,
            isDeleteOpen: false,
            totalApps: 0,
        };
    }

    /**
     * @memberof Listing
     */
    componentDidMount() {
        this.updateApps();
        this.isApplicationGroupSharingEnabled();
    }

    /**
     * retrieve Settings from the context and check the application sharing enabled
     * @param {*} settingsData required data
     */
    isApplicationGroupSharingEnabled = () => {
        const settingsContext = this.context;
        const enabled = settingsContext.settings.applicationSharingEnabled;
        this.setState({ isApplicationSharingEnabled: enabled });
    }

    /**
     * @memberof Listing
     */
    updateApps = () => {
        const {
            page, rowsPerPage, order, orderBy,
        } = this.state;
        const promisedApplications = Application.all(rowsPerPage, page * rowsPerPage, order, orderBy);
        promisedApplications
            .then((applications) => {
                const { pagination: { total } } = applications;
                // Applications list put into map, to make it efficient when deleting apps (referring back to an App)
                const apps = new Map();
                applications.list.map((app) => apps.set(app.applicationId, app)); // Store application against its UUID
                this.setState({ data: apps, totalApps: total });
            })
            .catch((error) => {
                console.log(error);
                const { status } = error;
                if (status === 404) {
                    // eslint-disable-next-line react/no-unused-state
                    this.setState({ notFound: true });
                } else if (status === 401) {
                    window.location = appSettings.context + '/services/configs';
                }
            });
    }

    /**
     * @inheritdoc
     */
    render() {
        const {
            data, open,
        } = this.state;
        if (!data) {
            return <Loading />;
        }
        const { classes, theme } = this.props;
        const strokeColorMain = theme.palette.getContrastText(theme.custom.infoBar.background);
        return (
            <main className={classes.content}>
                <div className={classes.root}>
                    <Box display='flex' flexDirection='row' justifyContent='flex-start' alignItems='center'>
                        <div className={classes.mainIconWrapper}>
                            <CustomIcon strokeColor={strokeColorMain} width={42} height={42} icon='applications' />
                        </div>
                        <div className={classes.mainTitleWrapper}>
                            <Typography variant='h4' className={classes.mainTitle}>
                                <FormattedMessage
                                    id='Applications.Listing.Listing.applications'
                                    defaultMessage='Applications'
                                />
                            </Typography>
                            {(data.size !== 0 || open) && (
                                <div className={classes.createLinkWrapper}>
                                    <ScopeValidation
                                        resourcePath={resourcePaths.APPLICATIONS}
                                        resourceMethod={resourceMethods.POST}
                                    >
                                        <Link to='/applications/create'>
                                            <Button
                                                variant='contained'
                                                color='primary'
                                            >
                                                <FormattedMessage
                                                    id='Applications.Create.Listing.add.new.application'
                                                    defaultMessage='Add New Application'
                                                />
                                            </Button>
                                        </Link>
                                    </ScopeValidation>
                                </div>
                            )}
                            {data && (
                                <Typography variant='caption' gutterBottom align='left'>
                                    {data.count === 0 && (
                                        <>
                                            <FormattedMessage
                                                id='Applications.Listing.Listing.no.applications.created'
                                                defaultMessage='No Applications created'
                                            />
                                        </>
                                    )}
                                </Typography>
                            )}
                        </div>
                    </Box>
                    <Box display='flex' pl={3}>
                        <Typography variant='caption' gutterBottom align='left'>
                            <FormattedMessage
                                id='Applications.Listing.Listing.logical.description'
                                defaultMessage={`An application is a logical collection of APIs.
                                        Applications allow you to use a single access token to invoke a
                                         collection of APIs and to subscribe to one API multiple times
                                          and allows unlimited access by default.`}
                            />
                        </Typography>
                    </Box>
                </div>
                <Grid container spacing={0} justify='center' className={classes.container}>
                    <Grid item xs={12}>
                        <div className={classes.appContent}>
                            <Grid
                                style={{ padding: '10px' }}
                                spacing={1}
                                container
                                direction='row'
                                justify='flex-start'
                                alignItems='center'
                            >
                                {[...data.values()].map((app) => (
                                    <Grid item xs={3}>
                                        <Card className={classes.card}>
                                            <CardActionArea>
                                                <Link to={'/applications/' + app.applicationId}>
                                                    <CardContent className={classes.media}>
                                                        <Typography gutterBottom variant='h5' component='h2'>
                                                            {app.name}
                                                        </Typography>
                                                        <Typography variant='body2' color='textSecondary' component='p'>
                                                            {app.description}
                                                        </Typography>
                                                    </CardContent>
                                                </Link>
                                            </CardActionArea>
                                            <CardActions>
                                                <Link to={`/applications/${app.applicationId}/edit/`}>
                                                    <Button variant='outlined' color='primary'>
                                                        Edit
                                                            </Button>
                                                </Link>

                                            </CardActions>
                                        </Card>
                                    </Grid>
                                ))}
                            </Grid>
                        </div>
                    </Grid>
                </Grid>
            </main>
        );
    }
}

export default injectIntl(withStyles(styles, { withTheme: true })(Listing));
